/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package com.mycompany.prog6112q1;

/**
 *
 * @author RC_Student_Lab
 */
public interface iProductSales {
    int TotalSales(int[][]productSales);
    double AverageSales(int[][]productSales);
    int MaxSales(int[][]productSales);
    int MinSale(int[][]productSales);
}
