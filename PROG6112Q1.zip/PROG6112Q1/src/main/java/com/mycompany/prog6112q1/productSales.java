/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.prog6112q1;

/**
 *
 * @author RC_Student_Lab
 */
public class productSales implements iProductSales{
      

  
    @Override
    public int TotalSales(int[][] productSales) {
        int total = 0;
        for (int[] yearSales : productSales) {
            for (int sales : yearSales) {
                total += sales;
            }
        }
        return total;
    }

    @Override
    public double AverageSales(int[][] productSales) {
        int total = TotalSales(productSales);
        
        int numQuarters = 0;
        for (int[] yearSales : productSales) {
            numQuarters += yearSales.length;
        }

        if (numQuarters == 0) {
            return 0.0;
        }

        return (double) total / numQuarters;
    }

    public int MaxSale(int[][] productSales) {
        int max = Integer.MIN_VALUE;

        for (int[] yearSales : productSales) {
            for (int sales : yearSales) {
                if (sales > max) {
                    max = sales;
                }
            }
        }
        return max;
    }

    @Override
    public int MinSale(int[][] productSales) {
        int min = Integer.MAX_VALUE;

        for (int[] yearSales : productSales) {
            for (int sales : yearSales) {
                if (sales < min) {
                    min = sales;
                }
            }
        }
        return min;
    }

    @Override
    public int MaxSales(int[][] productSales) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
} 

