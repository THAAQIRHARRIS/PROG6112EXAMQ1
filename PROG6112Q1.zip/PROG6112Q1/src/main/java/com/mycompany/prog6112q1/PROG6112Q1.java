/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.prog6112q1;

import java.util.Scanner;

/**
 *
 * @author RC_Student_Lab
 */
public class PROG6112Q1 {
    
    private static final int NUM_YEARS = 2;
    private static final int NUM_QUARTERS = 3;

    public static void main(String[] args) {
   
        Scanner scanner = new Scanner(System.in);

        int[][] salesData = new int[NUM_YEARS][NUM_QUARTERS];

        System.out.println("==========================================");
        System.out.println("  Product Sales Data Entry for 2 Years    ");
        System.out.println("==========================================");

        for (int i = 0; i < NUM_YEARS; i++) {
            System.out.println("\n--- Entering data for YEAR " + (i + 1) + " ---");
            for (int j = 0; j < NUM_QUARTERS; j++) {
           
                System.out.print("Enter sales for Quarter " + (j + 1) + ": ");
                
               
                while (!scanner.hasNextInt()) {
                    System.out.println("Invalid input. Please enter a whole number for sales.");
                    scanner.next(); 
                    System.out.print("Enter sales for Quarter " + (j + 1) + ": ");
                }
                
                salesData[i][j] = scanner.nextInt();
            }
        }

        scanner.close();

        
        productSales salesProcessor = new productSales();

        
        int total = salesProcessor.TotalSales(salesData);
        double average = salesProcessor.AverageSales(salesData);
        int maximum = salesProcessor.MaxSale(salesData);
        int minimum = salesProcessor.MinSale(salesData);

    
        int averageInt = (int) Math.round(average); 
        
        System.out.println("\n--------------------------------");
        System.out.println(" PRODUCT SALES REPORT - 2025    ");
        System.out.println("--------------------------------");
      
        System.out.printf("%-15s %d%n", "Total sales:", total);
        System.out.printf("%-15s %d%n", "Average sales:", averageInt);
        System.out.printf("%-15s %d%n", "Maximum sale:", maximum);
        System.out.printf("%-15s %d%n", "Minimum sale:", minimum);
        System.out.println("--------------------------------");
    }
}
